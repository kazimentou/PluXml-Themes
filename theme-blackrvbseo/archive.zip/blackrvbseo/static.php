<?php include(dirname(__FILE__).'/headerstatique.php'); ?>

	<main class="main grid" >

		<section class="col sml-12 med-8">


			<article class="article static"  id="static-page-<?php echo $plxShow->staticId(); ?>">

				<header>
					<h1>
						<?php $plxShow->staticTitle(); ?>
					</h1>
				</header>

				<section>
					<?php $plxShow->staticContent(); ?>
				</section>

			</article>

		</section>

		<?php include(dirname(__FILE__).'/sidebarstatique.php'); ?>

	</main>

<?php include(dirname(__FILE__).'/footerstatique.php'); ?>
