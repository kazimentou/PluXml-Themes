<?php include(dirname(__FILE__).'/header.php'); ?>
	<main class="main grid" role="main">
		<section class="col sml-12 med-8">
			<article class="article post type-post status-publish format-standard hentry " role="article" id="post-<?php echo $plxShow->artId(); ?>">
				<header class="entry-header">
					<div class="post-format-indicator"></div>
					<h1 class="entry-title"><?php $plxShow->artTitle(); ?></h1>
					<div class="entry-meta">
						<time datetime="<?php $plxShow->artDate('#num_year(4)-#num_month-#num_day'); ?>"><?php $plxShow->artDate('#num_day #month #num_year(4)'); ?></time>
						<span class="byline">
							<span class="sep"> | <?php $plxShow->lang('WRITTEN_BY'); ?> <?php $plxShow->artAuthor() ?>
							</span>
							<span class="sep"> |
								<a href="#comments" title="<?php $plxShow->artNbCom(); ?>"><?php $plxShow->artNbCom(); ?></a>
							</span>	
						</span>	
					</div><!-- .entry-meta -->
				</header><!-- .entry-header -->
				<div class="entry-content">
					<?php $plxShow->artContent(); ?>
				</div><!-- .entry-content -->

				<footer class="entry-meta">
					<span class="cat-links">
						<?php $plxShow->artCat() ?>
					</span>
			
					<span class="tags-links">
						<?php $plxShow->artTags() ?>
					</span>
				</footer><!-- .entry-meta -->
			</article>

			<?php include(dirname(__FILE__).'/commentaires.php'); ?>

		</section>

		<?php include(dirname(__FILE__).'/sidebar.php'); ?>

	</main>

<?php include(dirname(__FILE__).'/footer.php'); ?>
