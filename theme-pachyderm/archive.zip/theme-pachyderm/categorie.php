<?php include(dirname(__FILE__).'/header.php'); ?>

	<main class="main grid" role="main">

		<section class="col sml-12 med-8">

			<?php while($plxShow->plxMotor->plxRecord_arts->loop()): ?>

					<article class="article post type-post status-publish format-standard sticky hentry" role="article" id="post-<?php echo $plxShow->artId(); ?>">
					<header class="entry-header clear">
						<div class="post-format-indicator"></div>
						<h1 class="entry-title">
							<?php $plxShow->artTitle('link'); ?>
						</h1>
						<div class="entry-meta">
							<?php $plxShow->lang('WRITTEN_BY'); ?> <?php $plxShow->artAuthor() ?>				
						</div><!-- .entry-meta -->
					</header><!-- .entry-header -->

						<div class="entry-content">
						<p><?php $plxShow->artChapo(); ?></p>
					
					<footer class="entry-meta">
						<span class="cat-links">
							<?php $plxShow->artCat() ?>
						</span>
							
						<span class="tags-links">
							<?php $plxShow->artTags() ?>
						</span>
									
					</footer><!-- .entry-meta -->
				</article><!-- #post-## -->

			<?php endwhile; ?>

			<nav class="pagination text-center">
				<?php $plxShow->pagination(); ?>
			</nav>

			<span>
				<?php $plxShow->artFeed('rss',$plxShow->catId()); ?>
			</span>

		</section>

	</main>

<?php include(dirname(__FILE__).'/footer.php'); ?>
