<?php if (!defined('PLX_ROOT')) exit; ?>


<footer id="colophon" class="site-footer" role="contentinfo">
	<nav role="navigation" id="nav-below" class="navigation-paging">
	<h1 class="screen-reader-text">Post navigation</h1>
	<div class="previous"><a href="." ><span class="meta-nav">&laquo;</span></a></div>
	</nav><!-- #nav-below -->
			<div class="site-info">
				<a rel="nofollow" href="<?php $plxShow->urlRewrite('core/admin/'); ?>" title="<?php $plxShow->lang('ADMINISTRATION') ?>"><?php $plxShow->lang('ADMINISTRATION') ?></a>
				<span class="sep"> | </span>
				adapté du thème Pachyderm créé par <a href="http://carolinemoore.net/" rel="designer">Caroline Moore</a>.
			</div><!-- .site-info -->
	</footer><!-- #colophon -->
</div><!-- #page -->

</div><!-- #content -->
</div><!-- #primary -->

</div><!-- #main -->
<div id="secondary" class="widget-area" role="complementary">
</div><!-- #secondary -->
<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/navigation.js?ver=20120206'></script>
<script type='text/javascript' src='<?php $plxShow->template(); ?>/js/skip-link-focus-fix.js?ver=20130115'></script>
</body>
</html>
